
package Vista;

import Controlador.JPanel2_Control;
import com.toedter.calendar.JDateChooser;
import java.awt.Color;
import java.util.Date;
import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

public class JPanel2_Vista extends JPanel{
    
    public VentanaPrincipal_Vista vp;
    public JComboBox jcCodigo;
    public JLabel jlCodigo, jlNomPlan, jlJornada, jlFecha;
    public JTextField jtNomPlan;
    public JRadioButton jrD, jrN;
    public JDateChooser jdFecha;

    public JPanel2_Vista(VentanaPrincipal_Vista obj) {
        vp = obj;
        setBorder(new LineBorder(Color.RED));
//        setBackground(Color.CYAN);
        setBounds(50, 40, 500, 500);
        setLayout(null);
        GUI();
        setVisible(false);
    }
    public void GUI(){
        JPanel2_Control ctrl = new JPanel2_Control(this);
        codigoPlan(ctrl);
        nombrePlan(ctrl);
        jornada(ctrl);
        fecha(ctrl);
    }
    public void codigoPlan(JPanel2_Control obj){
        jlCodigo = new JLabel("Codigo del Plan");
        jlCodigo.setBounds(50, 10, 100, 30);
        add(jlCodigo);
        
        jcCodigo = new JComboBox<>();
        jcCodigo.addItem("");
        jcCodigo.addItem("2724");
        jcCodigo.addItem("2725");
        jcCodigo.addItem("2723");
        jcCodigo.setBounds(160, 10, 150, 30);
        jcCodigo.addActionListener(obj);
        add(jcCodigo);
    }
    public void nombrePlan(JPanel2_Control obj){
        jlNomPlan = new JLabel("Nombre del Plan");
        jlNomPlan.setBounds(50, 50, 100, 30);
        add(jlNomPlan);
        
        jtNomPlan = new JTextField();
        jtNomPlan.setBounds(160, 50, 150, 30);
        add(jtNomPlan);
    }
    public void jornada(JPanel2_Control obj){
        jlJornada = new JLabel("Jornada");
        jlJornada.setBounds(50, 90, 100, 30);
        jlJornada.setHorizontalAlignment(JLabel.CENTER);
        add(jlJornada);
        
        jrD = new JRadioButton("Diurna");
        jrD.setBounds(160, 90, 80, 30);
        jrD.addActionListener(obj);
        add(jrD);
        
        jrN = new JRadioButton("Nocturna");
        jrN.setBounds(240, 90, 100, 30);
        jrN.addActionListener(obj);
        add(jrN);
        
        ButtonGroup bg = new ButtonGroup();
        bg.add(jrD);
        bg.add(jrN);
    }
    public void fecha(JPanel2_Control obj){
        jlFecha = new JLabel("Fecha de ingreso");
        jlFecha.setBounds(50, 130, 100, 30);
        add(jlFecha);
        
        jdFecha = new JDateChooser(new Date());
        jdFecha.setBounds(160, 130, 150, 30);
        add(jdFecha);
    }
    
}
