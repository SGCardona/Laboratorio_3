package Vista;

import com.toedter.calendar.JDateChooser;
import java.awt.Color;
import java.util.Date;
import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;


public class JPanel1_Vista extends JPanel{

    public VentanaPrincipal_Vista vp;
    public JComboBox<String> jcTipoId;
    public JLabel jlNumId, jlNombre, jlApellido, jlDireccion, jlGenero, jlCorreo, jlFecha, jlCiudad, jlObservacion;
    public JTextField jtNumId, jtNombre, jtApellido, jtDireccion, jtCorreo, jtCiudad;
    public JTextArea jtObservaciones;
    public JRadioButton jrF, jrM;
    public JDateChooser jdFecha;
    
    
    public JPanel1_Vista(VentanaPrincipal_Vista obj) {
        vp = obj;
        setBorder(new LineBorder(Color.RED));
//        setBackground(Color.CYAN);
        setBounds(50, 40, 500, 500);
        setLayout(null);
        GUI();
        setVisible(false);    
    }
    public void GUI(){
        tipoId();
        numId();
        nombre();
        apellido();
        direccion();
        correo();
        ciudad();
        genero();
        fecha();
        Observaciones();
    }
    public void tipoId(){
        jcTipoId = new JComboBox<>();
        jcTipoId.addItem("Tipo de ID");
        jcTipoId.addItem("C.C");
        jcTipoId.addItem("T.I");
        jcTipoId.addItem("Extranjero");
        jcTipoId.setBounds(310, 10, 150, 30);
        add(jcTipoId);
    }
    public void numId(){
        jlNumId = new JLabel("Numero ID");
        jlNumId.setBounds(50, 10, 100, 30);
        add(jlNumId);
        
        jtNumId = new JTextField();
        jtNumId.setBounds(150, 10, 150, 30);
        add(jtNumId);
    }
    public void nombre(){
        jlNombre = new JLabel("Nombre");
        jlNombre.setBounds(50, 50, 100, 30);
        add(jlNombre);
        
        jtNombre = new JTextField();
        jtNombre.setBounds(150, 50, 150, 30);
        add(jtNombre);  
    }
    public void apellido(){
        jlApellido = new JLabel("Apellido");
        jlApellido.setBounds(50, 90, 100, 30);
        add(jlApellido);
        
        jtApellido = new JTextField();
        jtApellido.setBounds(150, 90, 150, 30);
        add(jtApellido);   
    }
    public void fecha(){
        jlFecha = new JLabel("Fecha nacimiento");
        jlFecha.setBounds(50, 290, 150, 30);
        add(jlFecha);
        
        jdFecha = new JDateChooser(new Date());
        jdFecha.setBounds(170, 290, 150, 30);
        add(jdFecha);
    }
    public void direccion(){
        jlDireccion = new JLabel("Direccion");
        jlDireccion.setBounds(50, 130, 100, 30);
        add(jlDireccion);
        
        jtDireccion = new JTextField();
        jtDireccion.setBounds(150, 130, 150, 30);
        add(jtDireccion);
    }
    public void correo(){
        jlCorreo = new JLabel("Correo");
        jlCorreo.setBounds(50, 170, 100, 30);
        add(jlCorreo);
        
        jtCorreo = new JTextField();
        jtCorreo.setBounds(150, 170, 150, 30);
        add(jtCorreo);
    }
    public void ciudad(){
        jlCiudad = new JLabel("Ciudad");
        jlCiudad.setBounds(50, 210, 100, 30);
        add(jlCiudad);
        
        jtCiudad = new JTextField();
        jtCiudad.setBounds(150, 210, 150, 30);
        add(jtCiudad);
    }
    public void genero(){
        jlGenero = new JLabel("Genero");
        jlGenero.setBounds(50, 250, 100, 30);
        add(jlGenero);
        
        jrF = new JRadioButton("Femenino");
        jrF.setBounds(150, 250, 80, 30);
        add(jrF);
        
        jrM = new JRadioButton("Masculino");
        jrM.setBounds(230, 250, 100, 30);
        add(jrM);
        
        ButtonGroup bg = new ButtonGroup();
        bg.add(jrF);
        bg.add(jrM);
        
    }
    public void Observaciones(){
        jlObservacion = new JLabel("Observacion");
        jlObservacion.setBounds(50, 330, 100, 30);
        add(jlObservacion);
        
        jtObservaciones = new JTextArea();
//        jtObservaciones.setBounds(150, 250, 150,100);
        JScrollPane js = new JScrollPane(jtObservaciones);
        js.setBounds(150, 330, 150,100);
        add(js);
        
    }
}
