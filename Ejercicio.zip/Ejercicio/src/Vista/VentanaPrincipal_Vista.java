
package Vista;

import Controlador.VentanaPrincipal_Control;
import javax.swing.JButton;
import javax.swing.JFrame;


public class VentanaPrincipal_Vista extends JFrame{
    
    public JButton jbPanel1, jbPanel2;
    public JPanel1_Vista jp1;
    public JPanel2_Vista jp2;

    public VentanaPrincipal_Vista() {
        super("Venta Principal");
        setSize(700, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);
        GUI();
        setVisible(true);
    }
    public void GUI(){
        VentanaPrincipal_Control ctrl = new VentanaPrincipal_Control(this);
        panel1(ctrl);
        panel2(ctrl);
    }
    public void panel1(VentanaPrincipal_Control obj){
        jp1 = new JPanel1_Vista(this);
        add(jp1);
        
        jbPanel1 = new JButton("Panel 1");
        jbPanel1.setBounds(50,0,295, 30);
        jbPanel1.addActionListener(obj);
        add(jbPanel1);
    }
    public void panel2(VentanaPrincipal_Control obj){
        jbPanel2 = new JButton("Panel 2");
        jbPanel2.setBounds(350,0,295, 30);
        jbPanel2.addActionListener(obj);
        add(jbPanel2);
        
        jp2 = new JPanel2_Vista(this);
        add(jp2);
    }
    
}
