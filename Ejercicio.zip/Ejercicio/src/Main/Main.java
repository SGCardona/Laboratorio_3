
package Main;

import Vista.VentanaPrincipal_Vista;

public class Main {


    public static void main(String[] args) {
        VentanaPrincipal_Vista vp = new VentanaPrincipal_Vista();
    }
    
}
