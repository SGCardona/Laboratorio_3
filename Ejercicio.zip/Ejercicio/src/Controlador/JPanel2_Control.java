
package Controlador;

import Vista.JPanel2_Vista;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JTextField;

public class JPanel2_Control implements ActionListener{

    public JPanel2_Vista jp2;
    
    public JPanel2_Control(JPanel2_Vista obj) {
        jp2 = obj;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource().equals(jp2.jcCodigo)){
           String item = (String) jp2.jcCodigo.getSelectedItem();
           
            switch (item) {
                case "2724":
                    jp2.jtNomPlan.setText("Desarrollo de software");
                    break;
                case "2725":
                    jp2.jtNomPlan.setText("Desarrollo de software 2");
                    break;
                case "2723":
                    jp2.jtNomPlan.setText("Desarrollo de software 3");
                    break;
                default:
                    jp2.jtNomPlan.setText("");
            }
        }
    }
    
    
}
