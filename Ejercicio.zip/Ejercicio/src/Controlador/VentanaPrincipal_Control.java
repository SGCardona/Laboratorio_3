
package Controlador;

import Vista.VentanaPrincipal_Vista;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaPrincipal_Control implements ActionListener{

    public VentanaPrincipal_Vista vp;
    
    public VentanaPrincipal_Control(VentanaPrincipal_Vista obj) {
        vp = obj;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource().equals(vp.jbPanel1)){
            vp.jp2.setVisible(false);
            vp.jp1.setVisible(true);
        }
        if(e.getSource().equals(vp.jbPanel2)){
            vp.jp1.setVisible(false);
            vp.jp2.setVisible(true);
        }
    }
    
}
